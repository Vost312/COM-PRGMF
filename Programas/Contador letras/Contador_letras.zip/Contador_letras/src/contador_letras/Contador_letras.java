package contador_letras;
public class Contador_letras {
    public static void main(String[] args) {
    archivos a = new archivos();
    String str = a.leerTxt("C:\\Users\\tonom\\Downloads\\Leer.txt");    //ubicacion del archivo
    Contador(str.toLowerCase());    //cambiamos a minusculas
    }
    public static void Contador(String str){
        int nLetras=0;  //variable para almacenar el numero de letras
        String strPalabras[]=str.split(" ");    //el delimitante es el espacio en blanco
        for(int i= 0; i<strPalabras.length; i++){   //para recorrer todo el string
            for(int j = 0; j<strPalabras[i].length(); j++){     //junto con nLetras++ es para aumentar cada que hay a una letra en el string
                nLetras++;
            }
        }
        System.out.println("Se encontraron "+nLetras+" simbolos");
    }
}
