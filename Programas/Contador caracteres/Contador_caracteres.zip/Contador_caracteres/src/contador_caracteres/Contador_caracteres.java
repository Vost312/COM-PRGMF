package contador_caracteres;
public class Contador_caracteres {
    public static void main(String[] args) {
    archivos a = new archivos();    
    String str = a.leerTxt("C:\\Users\\tonom\\Downloads\\Leer.txt");    //para trae el archivo txt de la direccion
    Contador(str.toLowerCase());    //a minusculas para evitar confuciones en la funcion ms adelante
    }
    public static void Contador(String str){    //definimos una variable para cada una de las letras que vamos a reconocer
        int letrasA=0, letrasB=0, letrasC=0, letrasD=0, letrasE=0, letrasF=0, letrasG=0, letrasH=0, letrasI=0, letrasJ=0, letrasK=0, letrasL=0, letrasM=0, letrasN=0, letrasO=0, letrasP=0, letrasQ=0, letrasR=0, letrasS=0, letrasT=0, letrasU=0, letrasV=0, letrasW=0, letrasX=0, letrasY=0, letrasZ=0, letrasp1=0, letrasp12=0, letrasp2=0, letrasp22=0, letrasp3=0, letrasp32=0, letrasmay=0, letrasmen=0, letraspunto=0, letraspunto1=0, letrasinte=0, letrasadm=0,letrasarro=0, letrasdiag=0, letrashash=0, letrasdin=0, letrasporc=0,letrasand=0, letrasigu=0, letrassum=0, letrasmult=0, letraspote=0, letrasgui=0, letrasguib=0, letrastalq=0, numeros0=0, numeros1=0, numeros2=0, numeros3=0, numeros4=0, numeros5=0, numeros6=0, numeros7=0, numeros8=0, numeros9=0;
        String a="a";//cada string es para guardar una letra, paraposteriormente compararla y asi aumentar la varibale asignada para cada ditpo de letra
        String b="b";
        String c="c";
        String d="d";
        String e="e";
        String f="f";
        String g="g";
        String h="h";
        String i="i";
        String j="j";
        String k="k";
        String l="l";
        String m="m";
        String n="n";
        String o="o";
        String p="p";
        String q="q";
        String r="r";
        String s="s";
        String t="t";
        String u="u";
        String v="v";
        String w="w";
        String x="x";
        String y="y";
        String z="z";
        String p1="{";
        String p12="}";
        String p2="[";
        String p22="]";
        String p3="(";
        String p32=")";
        String may=">";
        String men="<";
        String punto=".";
        String punto1=":";
        String inte="?";
        String adm="!";
        String arro="@";
        String diag="/";
        String hash="#";
        String din="$";
        String porc="%";
        String and="&";
        String igu="=";
        String sum="+";
        String mult="*";
        String pote="^";
        String gui="-";
        String guib="_";
        String talq="|";
        String num0="0";
        String num1="1";
        String num2="2";
        String num3="3";
        String num4="4";
        String num5="5";
        String num6="6";
        String num7="7";
        String num8="8";
        String num9="9";
        String strPalabras[]=str.split(" ");    //el delimitador entre palabras es un espacio
        for (String strPalabra : strPalabras) {
            for (int loop = 0; loop < strPalabra.length(); loop++) {    //segun recuerdo es para recorrer el arreglo
                String letra = String.valueOf(strPalabra.charAt(loop));     //recorrer cada letra si no mal recuerdo
                if(a.contains(letra)){      //de aqui en adelante, se compara con la letraactualmente leida, y si concide se aumenta, si no pasa a compararla con la siguientey asi sucesivamente hasta acabar con el string
                    letrasA++;
                }
                else if(b.contains(letra)){
                    letrasB++;
                }
                else if(c.contains(letra)){
                    letrasC++;
                }
                else if(d.contains(letra)){
                    letrasD++;
                }
                else if(e.contains(letra)){
                    letrasE++;
                }
                else if(f.contains(letra)){
                    letrasF++;
                }
                else if(g.contains(letra)){
                    letrasG++;
                }
                else if(h.contains(letra)){
                    letrasH++;
                }
                else if(i.contains(letra)){
                    letrasI++;
                }
                else if(j.contains(letra)){
                    letrasJ++;
                }
                else if(k.contains(letra)){
                    letrasK++;
                }
                else if(l.contains(letra)){
                    letrasL++;
                }
                else if(m.contains(letra)){
                    letrasM++;
                }
                else if(n.contains(letra)){
                    letrasN++;
                }
                else if(o.contains(letra)){
                    letrasO++;
                }
                else if(p.contains(letra)){
                    letrasP++;
                }
                else if(q.contains(letra)){
                    letrasQ++;
                }
                else if(r.contains(letra)){
                    letrasR++;
                }
                else if(s.contains(letra)){
                    letrasS++;
                }
                else if(t.contains(letra)){
                    letrasT++;
                }
                else if(u.contains(letra)){
                    letrasU++;
                }
                else if(v.contains(letra)){
                    letrasV++;
                }
                else if(w.contains(letra)){
                    letrasW++;
                }
                else if(x.contains(letra)){
                    letrasX++;
                }
                else if(y.contains(letra)){
                    letrasY++;
                }
                else if(z.contains(letra)){
                    letrasZ++;
                }
                else if(p1.contains(letra)){
                    letrasp1++;
                }
                else if(p12.contains(letra)){
                    letrasp12++;
                }
                else if(p2.contains(letra)){
                    letrasp2++;
                }
                else if(p22.contains(letra)){
                    letrasp22++;
                }
                else if(p3.contains(letra)){
                    letrasp3++;
                }
                else if(p32.contains(letra)){
                    letrasp32++;
                }
                else if(may.contains(letra)){
                    letrasmay++;
                }
                else if(men.contains(letra)){
                    letrasmen++;
                }
                else if(punto.contains(letra)){
                    letraspunto++;
                }
                else if(punto1.contains(letra)){
                    letraspunto1++;
                }
                else if(inte.contains(letra)){
                    letrasinte++;
                }
                else if(adm.contains(letra)){
                    letrasadm++;
                }
                else if(arro.contains(letra)){
                    letrasarro++;
                }
                else if(diag.contains(letra)){
                    letrasdiag++;
                }
                else if(hash.contains(letra)){
                    letrashash++;
                }
                else if(din.contains(letra)){
                    letrasdin++;
                }
                else if(porc.contains(letra)){
                    letrasporc++;
                }
                else if(and.contains(letra)){
                    letrasand++;
                }
                else if(igu.contains(letra)){
                    letrasigu++;
                }
                else if(sum.contains(letra)){
                    letrassum++;
                }
                else if(mult.contains(letra)){
                    letrasmult++;
                }
                else if(pote.contains(letra)){
                    letraspote++;
                }
                else if(gui.contains(letra)){
                    letrasgui++;
                }
                else if(guib.contains(letra)){
                    letrasguib++;
                }
                else if(talq.contains(letra)){
                    letrastalq++;
                }
                else if(num0.contains(letra)){
                    numeros0++;
                }
                else if(num1.contains(letra)){
                    numeros1++;
                }
                else if(num2.contains(letra)){
                    numeros2++;
                }
                else if(num3.contains(letra)){
                    numeros3++;
                }
                else if(num4.contains(letra)){
                    numeros4++;
                }
                else if(num5.contains(letra)){
                    numeros5++;
                }
                else if(num6.contains(letra)){
                    numeros6++;
                }
                else if(num7.contains(letra)){
                    numeros7++;
                }
                else if(num8.contains(letra)){
                    numeros8++;
                }
                else if(num9.contains(letra)){
                    numeros9++;
                }
            }
        }
        System.out.println("Se encontraron los siguientes caracteres:\n");
                                //a la hora de imprimir las letras, primero compara si no hay de esa letra, para asi no imprimirla si no hay ninguna del tipo
 		if(letrasA>0){
        	System.out.println("A = "+letrasA);                    
                }
                if(letrasB>0){
		System.out.println("B = "+letrasB);                 
                }
                 if(letrasC>0){
                System.out.println("C = "+letrasC);
                }
                 if(letrasD>0){
                System.out.println("D = "+letrasD);
                }
                 if(letrasE>0){
                System.out.println("E = "+letrasE);
                }
                 if(letrasF>0){
                System.out.println("F = "+letrasF);
                }
                 if(letrasG>0){
                System.out.println("G = "+letrasG);
                }
                 if(letrasH>0){
                System.out.println("H = "+letrasH);
                }
                 if(letrasI>0){
                System.out.println("I = "+letrasI);
                }
                 if(letrasJ>0){
                System.out.println("J = "+letrasJ);
                }
                 if(letrasK>0){
                System.out.println("K = "+letrasK);
                }
                 if(letrasL>0){
		System.out.println("L = "+letrasL);
                }
                 if(letrasM>0){
                System.out.println("M = "+letrasM);
                }
                 if(letrasN>0){
                System.out.println("N = "+letrasN);
                }
                 if(letrasO>0){
                System.out.println("O = "+letrasO);
                }
                 if(letrasP>0){
                System.out.println("P = "+letrasP);
                }
                 if(letrasQ>0){
                System.out.println("Q = "+letrasQ);
                }
                 if(letrasR>0){
                System.out.println("R = "+letrasR);
                }
                 if(letrasS>0){
                System.out.println("S = "+letrasS);
                }
                 if(letrasT>0){
                System.out.println("T = "+letrasT);
                }
                 if(letrasU>0){
                System.out.println("U = "+letrasU);
                }
                 if(letrasV>0){
                System.out.println("V = "+letrasV);
                }
                 if(letrasW>0){
                System.out.println("W = "+letrasW);
                }
                 if(letrasX>0){
                System.out.println("X = "+letrasX);
                }
                 if(letrasY>0){
                System.out.println("Y = "+letrasY);
                }
                 if(letrasZ>0){
                System.out.println("Z = "+letrasZ);
                }
                 if(letrasp1>0){
                System.out.println("{ = "+letrasp1);
                }
                 if(letrasp12>0){
                System.out.println("} = "+letrasp12);
                }
                 if(letrasp2>0){
                System.out.println("[ = "+letrasp2);
                }
                 if(letrasp22>0){
                System.out.println("] = "+letrasp22);
                }
                 if(letrasp3>0){
                System.out.println("( = "+letrasp3);
                }
                 if(letrasp32>0){
                System.out.println(") = "+letrasp32);
                }
                 if(letrasmay>0){
                System.out.println("> = "+letrasmay);
                }
                 if(letrasmen>0){
                System.out.println("< = "+letrasmen);
                }
                 if(letraspunto>0){
                System.out.println(". = "+letraspunto);    
                }
                 if(letraspunto1>0){
                System.out.println(": = "+letraspunto1);   
                }
                 if(letrasinte>0){
                System.out.println("? = "+letrasinte); 
                }
                 if(letrasadm>0){
                System.out.println("! = "+letrasadm);  
                }
                 if(letrasarro>0){
                System.out.println("@ = "+letrasarro);  
                }
                 if(letrasdiag>0){
                System.out.println("/ = "+letrasdiag);    
                }
                 if(letrashash>0){
                System.out.println("# = "+letrashash);   
                }
                 if(letrasdin>0){
                System.out.println("$ = "+letrasdin);
                }
                 if(letrasporc>0){
                System.out.println("% = "+letrasporc);
                }
                 if(letrasand>0){
                System.out.println("& = "+letrasand);   
                }
                 if(letrasigu>0){
                System.out.println("= = "+letrasigu);  
                }
                 if(letrassum>0){
                System.out.println("+ = "+letrassum);
                }
                 if(letrasmult>0){
                System.out.println("* = "+letrasmult);
                }
                 if(letraspote>0){
                System.out.println("^ = "+letraspote);
                }
                 if(letrasgui>0){
                System.out.println("- = "+letrasgui);  
                }
                 if(letrasguib>0){
                System.out.println("_ = "+letrasguib);    
                }
                 if(letrastalq>0){
                System.out.println("| = "+letrastalq);   
                }
                 if(numeros0>0){
                System.out.println("0 = "+numeros0); 
                }
                 if(numeros1>0){
                System.out.println("1 = "+numeros1); 
                }
                 if(numeros2>0){
                System.out.println("2 = "+numeros2);
                }
                 if(numeros3>0){
                System.out.println("3 = "+numeros3);
                }
                 if(numeros4>0){
                System.out.println("4 = "+numeros4);
                }
                 if(numeros5>0){
                System.out.println("5 = "+numeros5);
                }
                 if(numeros6>0){
                System.out.println("6 = "+numeros6);
                }
                 if(numeros7>0){
                System.out.println("7 = "+numeros7);
                }
                 if(numeros8>0){
                System.out.println("8 = "+numeros8);
                }
                 if(numeros9>0){
                System.out.println("9 = "+numeros9);
                }
    }
}
