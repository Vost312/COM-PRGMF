package contador_palabras;
public class Contador_palabras {
    public static void main(String[] args) {
    archivos a = new archivos();
    String str = a.leerTxt("C:\\Users\\tonom\\Downloads\\Leer.txt");    //especificar la dieccion del txt
    Contador(str.toLowerCase());    //las hacemos minusculas para evitar problemas de compatibilidad con la funcion
    }
    public static void Contador(String str){
        int nPalabras=0;    //variable para almacenar el numero de palabras
        String strPalabras[]=str.split(" ");    //reconocer que cada espacio es el delimitante
        nPalabras=strPalabras.length;   
        System.out.println("Se encontraron "+nPalabras+" palabras");
        
    }
}
